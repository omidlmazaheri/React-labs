import { useState } from "react";
import * as yup from 'yup';

function App() {


let emailSchmea = yup.string().min(8).max(12).email();


console.log(emailSchmea.isValidSync('am@gmail.com'))











  const [ form , setForm ] = useState({
    email : '',
    password : ''
  })

  const [errors , setErrors] = useState({
    email : null,
    password : null
  })

  const submitHandler = async (e) => {
    e.preventDefault()
    let formSchema = yup.object({
      email : yup.string().required().email(),
      password : yup.string().required().min(8)
    })


    try {
      await formSchema.validate(form, {
        abortEarly : false
      })
    } catch (error) {
      let allErrors = {}
      error.inner.forEach((err) => {
        allErrors[err.path] = err.message
      })

      setErrors(allErrors);
    }
  }

  const onChangeInput = (e) => {
    setForm({
      ...form,
      [e.target.name] : e.target.value
    })
  }


  return (
    <div className="App">
        <form onSubmit={submitHandler}>
            <label>Email</label>
            <input name="email" value={form.email} onChange={onChangeInput}/>
            { errors.email ? <span>{errors.email}</span>  : null }
            <br />
            <label>Password</label>
            <input name="password" value={form.password} onChange={onChangeInput}/>
            { errors.password ? <span>{errors.password}</span>  : null }
            <br />
            <button type="submit">send form</button>
        </form>
    </div>
  );
}

export default App;
